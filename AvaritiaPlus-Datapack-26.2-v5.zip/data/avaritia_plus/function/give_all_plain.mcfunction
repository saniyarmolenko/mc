tellraw @p {"text":"[Avaritia+] PLAIN TEST: видаю звичайні предмети без кастомних компонентів.","color":"yellow"}
give @p minecraft:netherite_helmet 1
give @p minecraft:netherite_chestplate 1
give @p minecraft:netherite_leggings 1
give @p minecraft:netherite_boots 1
give @p minecraft:mace 1