tellraw @p {"text":"[Avaritia+] VISUAL TEST: видаю предмети з item_model/equippable.","color":"yellow"}
function avaritia_plus:give_infinity_armor_visual_test
function avaritia_plus:give_reaper_scythe_visual_test