tellraw @a {"text":"[Avaritia+] v5 завантажено. Команди: /function avaritia_plus:give_all, /function avaritia_plus:create_fortress","color":"gold"}
scoreboard objectives add apDeathMark dummy
scoreboard objectives add apTrapCooldown dummy
scoreboard objectives add apTotemCharges dummy

scoreboard objectives add apFrostVortex dummy
scoreboard objectives add apVortexDmgCd dummy
