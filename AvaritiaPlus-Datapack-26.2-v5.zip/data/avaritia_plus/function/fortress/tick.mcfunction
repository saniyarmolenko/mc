# Continuous effect traps
execute as @e[type=minecraft:marker,tag=ap_trap_poison] at @s as @a[distance=..3] run effect give @s minecraft:poison 4 1 true
execute as @e[type=minecraft:marker,tag=ap_trap_poison] at @s as @a[distance=..3] run effect give @s minecraft:weakness 4 2 true
execute as @e[type=minecraft:marker,tag=ap_trap_freeze] at @s as @a[distance=..3] run effect give @s minecraft:slowness 4 5 true
execute as @e[type=minecraft:marker,tag=ap_trap_freeze] at @s as @a[distance=..3] run effect give @s minecraft:mining_fatigue 4 4 true
execute as @e[type=minecraft:marker,tag=ap_trap_freeze] at @s as @a[distance=..3] run particle minecraft:snowflake ~ ~1 ~ 1 1 1 0.02 20 force

# Cooldown traps
execute as @e[type=minecraft:marker,tag=ap_trap_arrows,scores={apTrapCooldown=0}] at @s if entity @a[distance=..4] run function avaritia_plus:fortress/trap_arrows
execute as @e[type=minecraft:marker,tag=ap_trap_arrows,scores={apTrapCooldown=0}] at @s if entity @a[distance=..4] run scoreboard players set @s apTrapCooldown 60

execute as @e[type=minecraft:marker,tag=ap_trap_blast,scores={apTrapCooldown=0}] at @s if entity @a[distance=..3] run function avaritia_plus:fortress/trap_blast
execute as @e[type=minecraft:marker,tag=ap_trap_blast,scores={apTrapCooldown=0}] at @s if entity @a[distance=..3] run scoreboard players set @s apTrapCooldown 160

execute as @e[type=minecraft:marker,tag=ap_trap_mobs,scores={apTrapCooldown=0}] at @s if entity @a[distance=..5] run function avaritia_plus:fortress/trap_mobs
execute as @e[type=minecraft:marker,tag=ap_trap_mobs,scores={apTrapCooldown=0}] at @s if entity @a[distance=..5] run scoreboard players set @s apTrapCooldown 600

execute as @e[type=minecraft:marker,tag=ap_trap_chest,scores={apTrapCooldown=0}] at @s if entity @a[distance=..3] run function avaritia_plus:fortress/trap_chest
execute as @e[type=minecraft:marker,tag=ap_trap_chest,scores={apTrapCooldown=0}] at @s if entity @a[distance=..3] run scoreboard players set @s apTrapCooldown 600
