playsound minecraft:entity.wither_skeleton.ambient hostile @a[distance=..20] ~ ~ ~ 1.0 0.8
summon minecraft:wither_skeleton ~2 ~ ~ {CustomName:'{"text":"Охоронець фортеці","color":"dark_gray"}',Health:30f}
summon minecraft:skeleton ~-2 ~ ~ {CustomName:'{"text":"Лучник фортеці","color":"gray"}',Health:24f}
summon minecraft:vindicator ~ ~ ~2 {CustomName:'{"text":"Страж скарбниці","color":"red"}',Health:30f}
particle minecraft:soul ~ ~1 ~ 1 1 1 0.05 35 force
