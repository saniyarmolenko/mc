playsound minecraft:block.dispenser.dispense hostile @a[distance=..16] ~ ~ ~ 1.0 1.0
summon minecraft:arrow ~-5 ~1.5 ~ {Motion:[1.4d,0.0d,0.0d],damage:7.0d,pickup:0b}
summon minecraft:arrow ~5 ~1.5 ~ {Motion:[-1.4d,0.0d,0.0d],damage:7.0d,pickup:0b}
summon minecraft:arrow ~ ~1.5 ~-5 {Motion:[0.0d,0.0d,1.4d],damage:7.0d,pickup:0b}
summon minecraft:arrow ~ ~1.5 ~5 {Motion:[0.0d,0.0d,-1.4d],damage:7.0d,pickup:0b}
particle minecraft:crit ~ ~1 ~ 2 0.5 2 0.05 30 force
