particle minecraft:explosion ~ ~1 ~ 1 1 1 0.05 1 force
particle minecraft:smoke ~ ~1 ~ 1 1 1 0.05 40 force
playsound minecraft:entity.generic.explode hostile @a[distance=..24] ~ ~ ~ 0.8 1.2
damage @a[distance=..4] 6 minecraft:magic
effect give @a[distance=..4] minecraft:slowness 5 2 true
