tellraw @a[distance=..10] {"text":"Пастка скарбниці активована!","color":"red"}
effect give @a[distance=..5] minecraft:blindness 4 0 true
effect give @a[distance=..5] minecraft:slowness 6 3 true
summon minecraft:vex ~1 ~1 ~ {CustomName:'{"text":"Дух скарбниці","color":"dark_purple"}'}
summon minecraft:vex ~-1 ~1 ~ {CustomName:'{"text":"Дух скарбниці","color":"dark_purple"}'}
particle minecraft:witch ~ ~1 ~ 1 1 1 0.04 50 force
playsound minecraft:entity.evoker.prepare_attack hostile @a[distance=..16] ~ ~ ~ 1.0 1.0
