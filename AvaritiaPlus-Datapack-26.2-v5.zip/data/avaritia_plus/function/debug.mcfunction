tellraw @a {"text":"[Avaritia+] DEBUG v4: datapack працює. Видаю діамант і тестову палку.","color":"aqua"}
give @p minecraft:diamond 1
give @p minecraft:stick[minecraft:custom_name='{"text":"Avaritia+ v4 test stick","color":"green"}'] 1
