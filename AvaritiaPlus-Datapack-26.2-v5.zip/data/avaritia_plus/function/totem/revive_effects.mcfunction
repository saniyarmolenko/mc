effect clear @s minecraft:poison
effect clear @s minecraft:wither
effect clear @s minecraft:slowness
effect clear @s minecraft:weakness
effect clear @s minecraft:blindness
effect give @s minecraft:regeneration 45 4 true
effect give @s minecraft:absorption 60 4 true
effect give @s minecraft:fire_resistance 60 0 true
effect give @s minecraft:resistance 20 2 true
effect give @s minecraft:health_boost 60 4 true
effect give @s minecraft:night_vision 60 0 true
particle minecraft:totem_of_undying ~ ~1 ~ 0.7 1.0 0.7 0.2 80 force
playsound minecraft:item.totem.use player @s ~ ~ ~ 1.0 1.0
