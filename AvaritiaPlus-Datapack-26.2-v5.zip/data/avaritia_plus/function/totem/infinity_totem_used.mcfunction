advancement revoke @s only avaritia_plus:infinity_totem_used
execute if score @s apTotemCharges matches 1.. run scoreboard players remove @s apTotemCharges 1
function avaritia_plus:totem/revive_effects
execute if score @s apTotemCharges matches 1.. run give @s minecraft:totem_of_undying[minecraft:custom_name='{"text":"Тотем нескінченості","color":"gold","bold":true}',minecraft:lore=['{"text":"Заряди відображаються в чаті після спрацювання","color":"yellow"}','{"text":"Працює через datapack scoreboard","color":"gray"}'],minecraft:custom_data={avaritia_plus:{id:"infinity_totem"}},minecraft:item_model="avaritia_plus:infinity_totem",minecraft:enchantment_glint_override=true] 1
execute if score @s apTotemCharges matches 1.. run tellraw @s [{"text":"[Avaritia+] Тотем спрацював. Зарядів залишилось: ","color":"gold"},{"score":{"name":"@s","objective":"apTotemCharges"},"color":"yellow"}]
execute if score @s apTotemCharges matches 0 run tellraw @s {"text":"[Avaritia+] Це був останній заряд Тотема нескінченості.","color":"red"}
