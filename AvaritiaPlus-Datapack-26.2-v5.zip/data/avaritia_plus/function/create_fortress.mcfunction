tellraw @p {"text":"[Avaritia+] Створюю фортецю 35×35 з пастками без TNT...","color":"gold"}
# Clear and base
fill ~-18 ~ ~-18 ~18 ~14 ~18 air replace
fill ~-18 ~-1 ~-18 ~18 ~-1 ~18 polished_blackstone_bricks
fill ~-18 ~0 ~-18 ~18 ~10 ~18 deepslate_bricks hollow
fill ~-16 ~1 ~-16 ~16 ~9 ~16 air
# Gate
fill ~-3 ~0 ~-18 ~3 ~4 ~-18 air
fill ~-4 ~5 ~-18 ~4 ~7 ~-18 polished_blackstone_bricks
# Towers
fill ~-18 ~0 ~-18 ~-13 ~14 ~-13 polished_blackstone_bricks hollow
fill ~13 ~0 ~-18 ~18 ~14 ~-13 polished_blackstone_bricks hollow
fill ~-18 ~0 ~13 ~-13 ~14 ~18 polished_blackstone_bricks hollow
fill ~13 ~0 ~13 ~18 ~14 ~18 polished_blackstone_bricks hollow
fill ~-17 ~1 ~-17 ~-14 ~13 ~-14 air
fill ~14 ~1 ~-17 ~17 ~13 ~-14 air
fill ~-17 ~1 ~14 ~-14 ~13 ~17 air
fill ~14 ~1 ~14 ~17 ~13 ~17 air
# Inner keep and corridors
fill ~-6 ~0 ~-6 ~6 ~8 ~6 deepslate_tiles hollow
fill ~-4 ~1 ~-4 ~4 ~6 ~4 air
fill ~-2 ~1 ~-6 ~2 ~4 ~-6 air
fill ~-2 ~1 ~6 ~2 ~4 ~6 air
fill ~-6 ~1 ~-2 ~-6 ~4 ~2 air
fill ~6 ~1 ~-2 ~6 ~4 ~2 air
fill ~-2 ~0 ~-18 ~2 ~0 ~18 polished_blackstone
fill ~-18 ~0 ~-2 ~18 ~0 ~2 polished_blackstone
# Lava pits without TNT
fill ~-11 ~-1 ~-2 ~-7 ~-1 ~2 lava
fill ~7 ~-1 ~-2 ~11 ~-1 ~2 lava
fill ~-11 ~0 ~-2 ~-7 ~0 ~2 air
fill ~7 ~0 ~-2 ~11 ~0 ~2 air
# Arrow trap markers
summon minecraft:marker ~0 ~1 ~-10 {Tags:["ap_trap","ap_trap_arrows"]}
scoreboard players set @e[type=minecraft:marker,tag=ap_trap_arrows,distance=..1,sort=nearest,limit=1] apTrapCooldown 0
# Poison/frost/slow traps
summon minecraft:marker ~8 ~1 ~0 {Tags:["ap_trap","ap_trap_poison"]}
scoreboard players set @e[type=minecraft:marker,tag=ap_trap_poison,distance=..1,sort=nearest,limit=1] apTrapCooldown 0
summon minecraft:marker ~-8 ~1 ~0 {Tags:["ap_trap","ap_trap_freeze"]}
scoreboard players set @e[type=minecraft:marker,tag=ap_trap_freeze,distance=..1,sort=nearest,limit=1] apTrapCooldown 0
# Safe blast trap and mob trap
summon minecraft:marker ~0 ~1 ~0 {Tags:["ap_trap","ap_trap_blast"]}
scoreboard players set @e[type=minecraft:marker,tag=ap_trap_blast,distance=..1,sort=nearest,limit=1] apTrapCooldown 0
summon minecraft:marker ~0 ~1 ~8 {Tags:["ap_trap","ap_trap_mobs"]}
scoreboard players set @e[type=minecraft:marker,tag=ap_trap_mobs,distance=..1,sort=nearest,limit=1] apTrapCooldown 0
# Treasure room and fake chest trap
setblock ~0 ~1 ~12 chest{CustomName:'{"text":"Скарбниця фортеці","color":"gold"}',Items:[{Slot:0b,id:"minecraft:diamond",count:16},{Slot:1b,id:"minecraft:emerald",count:32},{Slot:2b,id:"minecraft:golden_apple",count:3}]} replace
summon minecraft:marker ~0 ~1 ~12 {Tags:["ap_trap","ap_trap_chest"]}
scoreboard players set @e[type=minecraft:marker,tag=ap_trap_chest,distance=..1,sort=nearest,limit=1] apTrapCooldown 0
# Lighting
setblock ~0 ~5 ~0 glowstone replace
setblock ~12 ~4 ~12 lantern replace
setblock ~-12 ~4 ~12 lantern replace
setblock ~12 ~4 ~-12 lantern replace
setblock ~-12 ~4 ~-12 lantern replace
# Warning
tellraw @p {"text":"[Avaritia+] Фортеця створена. Пастки без TNT: лава, стріли, ефекти, моби, безпечний вибух.","color":"green"}
