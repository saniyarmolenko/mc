# Visual + anti-lag Death Volley. It does not spawn 255 physical arrows.
particle minecraft:soul_fire_flame ^ ^ ^2 0.5 0.3 0.5 0.04 30 force
particle minecraft:soul ^ ^ ^4 1.0 0.5 1.0 0.04 50 force
playsound minecraft:entity.wither.shoot hostile @a[distance=..24] ~ ~ ~ 0.8 0.5
execute positioned ^ ^ ^4 as @e[distance=..2,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident] run function avaritia_plus:weapons/death_crossbow_apply_effects
execute positioned ^2 ^ ^6 as @e[distance=..2,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident] run function avaritia_plus:weapons/death_crossbow_apply_effects
execute positioned ^-2 ^ ^6 as @e[distance=..2,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident] run function avaritia_plus:weapons/death_crossbow_apply_effects
execute positioned ^ ^1 ^7 as @e[distance=..2,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident] run function avaritia_plus:weapons/death_crossbow_apply_effects
execute positioned ^ ^-1 ^7 as @e[distance=..2,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident] run function avaritia_plus:weapons/death_crossbow_apply_effects
