# Visual orbit: 8 icy shuriken points around the player. 25 seconds = 500 ticks.
particle minecraft:snowflake ~3 ~1 ~ 0.08 0.08 0.08 0.01 8 force
particle minecraft:snowflake ~-3 ~1 ~ 0.08 0.08 0.08 0.01 8 force
particle minecraft:snowflake ~ ~1 ~3 0.08 0.08 0.08 0.01 8 force
particle minecraft:snowflake ~ ~1 ~-3 0.08 0.08 0.08 0.01 8 force
particle minecraft:crit ~2.1 ~1 ~2.1 0.05 0.05 0.05 0.01 5 force
particle minecraft:crit ~-2.1 ~1 ~2.1 0.05 0.05 0.05 0.01 5 force
particle minecraft:crit ~2.1 ~1 ~-2.1 0.05 0.05 0.05 0.01 5 force
particle minecraft:crit ~-2.1 ~1 ~-2.1 0.05 0.05 0.05 0.01 5 force
# Damage/effects every 10 ticks (0.5 seconds) to avoid lag.
execute if score @s apVortexDmgCd matches 0 as @e[distance=0.6..4,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident] run function avaritia_plus:weapons/frost_vortex_hit
execute if score @s apVortexDmgCd matches 0 run scoreboard players set @s apVortexDmgCd 10
