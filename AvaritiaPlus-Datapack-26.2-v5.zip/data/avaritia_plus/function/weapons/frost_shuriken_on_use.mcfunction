# Runs from advancement while a player is using any item. Only Frost Shuriken activates the vortex.
advancement revoke @s only avaritia_plus:frost_shuriken_use
execute if items entity @s weapon.mainhand minecraft:trident[minecraft:custom_data~{avaritia_plus:{id:"frost_shuriken"}}] unless score @s apFrostVortex matches 1.. run function avaritia_plus:weapons/frost_vortex_start_fx
execute if items entity @s weapon.mainhand minecraft:trident[minecraft:custom_data~{avaritia_plus:{id:"frost_shuriken"}}] run scoreboard players set @s apFrostVortex 500
execute if items entity @s weapon.offhand minecraft:trident[minecraft:custom_data~{avaritia_plus:{id:"frost_shuriken"}}] unless score @s apFrostVortex matches 1.. run function avaritia_plus:weapons/frost_vortex_start_fx
execute if items entity @s weapon.offhand minecraft:trident[minecraft:custom_data~{avaritia_plus:{id:"frost_shuriken"}}] run scoreboard players set @s apFrostVortex 500
