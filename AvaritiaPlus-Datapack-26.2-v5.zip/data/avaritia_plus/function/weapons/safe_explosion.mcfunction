particle minecraft:explosion ~ ~1 ~ 0.7 0.7 0.7 0.04 1 force
particle minecraft:soul ~ ~1 ~ 1.2 0.8 1.2 0.04 40 force
playsound minecraft:entity.generic.explode hostile @a[distance=..24] ~ ~ ~ 0.8 1.0
# Safe damage without TNT and without block destruction.
damage @e[distance=0.1..4,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident] 8 minecraft:magic
