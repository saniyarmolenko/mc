advancement revoke @s only avaritia_plus:lava_mace_hit
execute if items entity @s weapon.mainhand minecraft:mace[minecraft:custom_data~{avaritia_plus:{id:"lava_mace"}}] at @s as @e[distance=0.1..7,sort=nearest,limit=1,nbt={HurtTime:10s}] run function avaritia_plus:weapons/lava_mace_apply_effects
