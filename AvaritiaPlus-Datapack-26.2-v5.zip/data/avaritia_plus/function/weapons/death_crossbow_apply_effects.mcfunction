effect give @s minecraft:wither 30 1 true
effect give @s minecraft:weakness 30 9 true
effect give @s minecraft:slowness 30 3 true
effect give @s minecraft:blindness 5 0 true
effect give @s minecraft:nausea 5 0 true
tag @s add ap_death_marked
scoreboard players set @s apDeathMark 60
particle minecraft:soul_fire_flame ~ ~1 ~ 0.7 0.7 0.7 0.03 35 force
playsound minecraft:entity.wither.shoot hostile @a[distance=..20] ~ ~ ~ 0.6 0.6
