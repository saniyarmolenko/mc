# 5 minutes = 300 seconds. Amplifier is level - 1.
effect give @s minecraft:slowness 300 2 true
effect give @s minecraft:blindness 300 0 true
effect give @s minecraft:nausea 300 0 true
effect give @s minecraft:mining_fatigue 300 10 true
effect give @s minecraft:wither 300 0 true
effect give @s minecraft:poison 300 0 true
effect give @s minecraft:weakness 300 9 true
function avaritia_plus:weapons/safe_explosion
