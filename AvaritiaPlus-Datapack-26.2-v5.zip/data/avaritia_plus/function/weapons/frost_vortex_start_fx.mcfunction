scoreboard players set @s apFrostVortex 500
tellraw @s {"text":"[Avaritia+] Крижаний вихор сюрикенів активовано на 25 секунд","color":"aqua"}
playsound minecraft:block.glass.break player @s ~ ~ ~ 1 1.5
particle minecraft:snowflake ~ ~1 ~ 1.8 1.0 1.8 0.05 120 force
scoreboard players set @s apVortexDmgCd 0
