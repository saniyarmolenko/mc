tag @s remove ap_death_marked
scoreboard players reset @s apDeathMark
particle minecraft:explosion ~ ~1 ~ 0.7 0.7 0.7 0.04 1 force
particle minecraft:soul_fire_flame ~ ~1 ~ 1.0 0.8 1.0 0.05 70 force
playsound minecraft:entity.wither.death hostile @a[distance=..28] ~ ~ ~ 0.5 1.4
damage @s 10 minecraft:magic
damage @e[distance=0.1..3,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:marker,type=!minecraft:arrow,type=!minecraft:spectral_arrow,type=!minecraft:trident] 6 minecraft:magic
