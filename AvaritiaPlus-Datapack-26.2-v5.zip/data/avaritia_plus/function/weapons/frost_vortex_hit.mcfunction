# One pulse of the Frost Shuriken Vortex.
damage @s 5 minecraft:magic
effect give @s minecraft:slowness 3 3 true
effect give @s minecraft:mining_fatigue 3 4 true
effect give @s minecraft:weakness 3 2 true
effect give @s minecraft:blindness 2 0 true
particle minecraft:snowflake ~ ~1 ~ 0.4 0.5 0.4 0.03 30 force
playsound minecraft:block.glass.break hostile @a[distance=..16] ~ ~ ~ 0.35 1.8
