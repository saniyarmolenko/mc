effect give @s minecraft:slowness 45 9 true
effect give @s minecraft:mining_fatigue 45 10 true
effect give @s minecraft:weakness 45 9 true
effect give @s minecraft:blindness 8 0 true
effect give @s minecraft:nausea 8 0 true
effect give @s minecraft:glowing 20 0 true
particle minecraft:snowflake ~ ~1 ~ 0.8 0.8 0.8 0.04 60 force
particle minecraft:poof ~ ~1 ~ 0.6 0.6 0.6 0.02 30 force
playsound minecraft:block.glass.break hostile @a[distance=..16] ~ ~ ~ 0.7 1.7
