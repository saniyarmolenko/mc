scoreboard players reset @s apFrostVortex
scoreboard players reset @s apVortexDmgCd
particle minecraft:poof ~ ~1 ~ 0.8 0.8 0.8 0.02 30 force
tellraw @s {"text":"[Avaritia+] Крижаний вихор згас","color":"gray"}
