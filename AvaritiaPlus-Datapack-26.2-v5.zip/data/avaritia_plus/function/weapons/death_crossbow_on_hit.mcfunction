advancement revoke @s only avaritia_plus:death_crossbow_hit
execute if items entity @s weapon.mainhand minecraft:crossbow[minecraft:custom_data~{avaritia_plus:{id:"death_crossbow"}}] at @s as @e[distance=0.1..80,sort=nearest,limit=1,nbt={HurtTime:10s}] run function avaritia_plus:weapons/death_crossbow_apply_effects
execute if items entity @s weapon.offhand minecraft:crossbow[minecraft:custom_data~{avaritia_plus:{id:"death_crossbow"}}] at @s as @e[distance=0.1..80,sort=nearest,limit=1,nbt={HurtTime:10s}] run function avaritia_plus:weapons/death_crossbow_apply_effects
