# Fire tag works for mobs. Player entity NBT cannot be modified directly, so players get fire-type damage instead.
execute unless entity @s[type=minecraft:player] run data merge entity @s {Fire:300s}
execute if entity @s[type=minecraft:player] run damage @s 6 minecraft:in_fire
effect give @s minecraft:glowing 8 0 true
particle minecraft:flame ~ ~1 ~ 0.6 0.8 0.6 0.05 40 force
particle minecraft:lava ~ ~1 ~ 0.4 0.5 0.4 0.02 12 force
playsound minecraft:block.lava.pop hostile @a[distance=..16] ~ ~ ~ 0.8 0.8
