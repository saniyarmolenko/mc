advancement revoke @s only avaritia_plus:death_crossbow_shot
execute if items entity @s weapon.mainhand minecraft:crossbow[minecraft:custom_data~{avaritia_plus:{id:"death_crossbow"}}] at @s anchored eyes run function avaritia_plus:weapons/death_crossbow_volley
execute if items entity @s weapon.offhand minecraft:crossbow[minecraft:custom_data~{avaritia_plus:{id:"death_crossbow"}}] at @s anchored eyes run function avaritia_plus:weapons/death_crossbow_volley
