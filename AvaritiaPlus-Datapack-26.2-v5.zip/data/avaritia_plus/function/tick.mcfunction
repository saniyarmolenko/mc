# Armor effects
execute as @a if items entity @s armor.head minecraft:netherite_helmet[minecraft:custom_data~{avaritia_plus:{id:"infinity_helmet"}}] if items entity @s armor.chest minecraft:netherite_chestplate[minecraft:custom_data~{avaritia_plus:{id:"infinity_chestplate"}}] if items entity @s armor.legs minecraft:netherite_leggings[minecraft:custom_data~{avaritia_plus:{id:"infinity_leggings"}}] if items entity @s armor.feet minecraft:netherite_boots[minecraft:custom_data~{avaritia_plus:{id:"infinity_boots"}}] run function avaritia_plus:armor/infinity_full_set

# Frost Shuriken Vortex timers
scoreboard players remove @a[scores={apFrostVortex=1..}] apFrostVortex 1
scoreboard players remove @a[scores={apVortexDmgCd=1..}] apVortexDmgCd 1
execute as @a[scores={apFrostVortex=1..}] at @s run function avaritia_plus:weapons/frost_vortex_tick
execute as @a[scores={apFrostVortex=0}] at @s run function avaritia_plus:weapons/frost_vortex_stop

# Death mark timers
scoreboard players remove @e[tag=ap_death_marked,scores={apDeathMark=1..}] apDeathMark 1
execute as @e[tag=ap_death_marked,scores={apDeathMark=0}] at @s run function avaritia_plus:weapons/death_mark_explode

# Fortress trap cooldowns
scoreboard players remove @e[type=minecraft:marker,tag=ap_trap,scores={apTrapCooldown=1..}] apTrapCooldown 1
function avaritia_plus:fortress/tick
