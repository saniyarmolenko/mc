tellraw @p {"text":"[Avaritia+] Видаю всі предмети v4...","color":"yellow"}
function avaritia_plus:give_infinity_armor
function avaritia_plus:give_reaper_scythe
function avaritia_plus:give_lava_mace
function avaritia_plus:give_frost_shuriken
function avaritia_plus:give_death_crossbow
function avaritia_plus:give_infinity_totem
tellraw @p {"text":"[Avaritia+] Готово. Якщо інвентар повний — частина предметів могла не влізти.","color":"green"}
