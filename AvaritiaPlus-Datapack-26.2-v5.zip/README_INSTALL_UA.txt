Avaritia+ v5 для Minecraft Java 26.2

Встановлення:
1. AvaritiaPlus-Datapack-26.2-v5.zip покласти у .minecraft/saves/Назва_світу/datapacks/
2. AvaritiaPlus-ResourcePack-26.2-v5.zip покласти у .minecraft/resourcepacks/
3. Увімкнути resource pack у грі
4. У світі виконати /reload
5. Видати всі предмети: /function avaritia_plus:give_all
6. Створити фортецю: /function avaritia_plus:create_fortress

Нове у v5:
- Обморожений сюрикен отримав Крижаний вихор сюрикенів на 25 секунд після використання/кидка.
- Вихор рухається разом із гравцем, має 8 точок навколо гравця, наносить 5 HP магічного урону кожні 0.5 секунди ворогам у радіусі до 4 блоків.
- Додає короткий стан/замороження: Slowness IV, Mining Fatigue V, Weakness III, Blindness.
- Ефект не стакатиметься: повторне використання оновлює таймер до 25 секунд.
- Лавова булава стала безпечнішою проти гравців: без помилки data merge для player entity.

Команди перевірки:
/function avaritia_plus:debug
/function avaritia_plus:give_frost_shuriken
/function avaritia_plus:weapons/frost_vortex_start_fx
