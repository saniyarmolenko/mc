Avaritia+ v4 Resource Pack для Minecraft Java 26.2

Поклади цей ZIP у .minecraft/resourcepacks/ і увімкни в Options → Resource Packs.
Пак містить кастомні іконки для броні, коси, лавової булави, сюрикена, арбалета і тотема.
