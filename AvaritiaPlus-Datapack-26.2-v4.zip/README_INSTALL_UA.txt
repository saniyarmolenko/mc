Avaritia+ v4 Datapack для Minecraft Java 26.2

Команди після /reload:
/function avaritia_plus:debug
/function avaritia_plus:give_all
/function avaritia_plus:give_all_safe
/function avaritia_plus:create_fortress

Новинки v4:
- Коса жнеця: ефекти 5 хвилин + безпечний вибух без TNT
- Лавова булава: підпалювання
- Обморожений сюрикен: замороження + стан
- Арбалет смерті: Multishot 255 + Death Volley + Мітка смерті
- Тотем нескінченості: 100 зарядів через scoreboard
- Фортеця 35x35 з пастками без TNT

Якщо /function avaritia_plus:give_all видає помилку через item_model, спробуй:
/function avaritia_plus:give_all_safe
