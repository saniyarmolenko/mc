# Fire tag works for mobs; Fire Aspect enchantment handles most melee fire behavior.
data merge entity @s {Fire:300s}
effect give @s minecraft:glowing 8 0 true
particle minecraft:flame ~ ~1 ~ 0.6 0.8 0.6 0.05 40 force
particle minecraft:lava ~ ~1 ~ 0.4 0.5 0.4 0.02 12 force
playsound minecraft:block.lava.pop hostile @a[distance=..16] ~ ~ ~ 0.8 0.8
