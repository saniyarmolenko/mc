advancement revoke @s only avaritia_plus:frost_shuriken_hit
execute if items entity @s weapon.mainhand minecraft:trident[minecraft:custom_data~{avaritia_plus:{id:"frost_shuriken"}}] at @s as @e[distance=0.1..9,sort=nearest,limit=1,nbt={HurtTime:10s}] run function avaritia_plus:weapons/frost_shuriken_apply_effects
execute if items entity @s weapon.offhand minecraft:trident[minecraft:custom_data~{avaritia_plus:{id:"frost_shuriken"}}] at @s as @e[distance=0.1..9,sort=nearest,limit=1,nbt={HurtTime:10s}] run function avaritia_plus:weapons/frost_shuriken_apply_effects
