tellraw @a {"text":"[Avaritia+] v4 завантажено. Команди: /function avaritia_plus:give_all, /function avaritia_plus:create_fortress","color":"gold"}
scoreboard objectives add apDeathMark dummy
scoreboard objectives add apTrapCooldown dummy
scoreboard objectives add apTotemCharges dummy
