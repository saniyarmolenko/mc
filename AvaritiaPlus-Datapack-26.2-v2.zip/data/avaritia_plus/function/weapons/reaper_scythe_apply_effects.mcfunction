# Reaper Scythe target effects.
# Slowness 3 = amplifier 2. Weakness 10 = amplifier 9.
# "Стан" is simulated using short blindness, nausea and mining fatigue because vanilla Minecraft has no true stun effect.
effect give @s minecraft:slowness 8 2 true
effect give @s minecraft:blindness 3 0 true
effect give @s minecraft:nausea 5 0 true
effect give @s minecraft:mining_fatigue 3 10 true
effect give @s minecraft:wither 8 0 true
effect give @s minecraft:poison 8 0 true
effect give @s minecraft:weakness 8 9 true
particle minecraft:soul ~ ~1 ~ 0.4 0.6 0.4 0.02 18 force
playsound minecraft:entity.wither.hurt hostile @a[distance=..16] ~ ~ ~ 0.6 0.7
