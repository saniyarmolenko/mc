# Triggered by advancement when player hurts an entity.
# Revoke the advancement so it can trigger again on the next hit.
advancement revoke @s only avaritia_plus:reaper_scythe_hit

# Apply effects only if the player is holding the custom Reaper Scythe.
execute if items entity @s weapon.mainhand minecraft:mace[minecraft:custom_data~{avaritia_plus:{id:"reaper_scythe"}}] at @s as @e[distance=0.1..7,sort=nearest,limit=1,nbt={HurtTime:10s}] run function avaritia_plus:weapons/reaper_scythe_apply_effects
