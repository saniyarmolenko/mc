# Avaritia+ load function
scoreboard objectives add avp_dummy dummy
scoreboard objectives add avp_timer dummy
tellraw @a {"text":"[Avaritia+] Броня нескінченості + Коса жнеця завантажені","color":"gold"}
