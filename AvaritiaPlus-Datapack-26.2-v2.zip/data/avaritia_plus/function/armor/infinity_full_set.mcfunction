# Full Infinity Armor set effects.
# Minecraft effect amplifier is level - 1.
effect give @s minecraft:regeneration 3 9 true
effect give @s minecraft:strength 3 4 true
effect give @s minecraft:resistance 3 4 true
effect give @s minecraft:health_boost 3 14 true
effect give @s minecraft:speed 3 4 true
effect give @s minecraft:jump_boost 3 4 true
effect give @s minecraft:night_vision 15 0 true
effect give @s minecraft:invisibility 3 0 true
