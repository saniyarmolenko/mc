Avaritia+ Datapack для Minecraft Java 26.2

Встановлення:
1. Відкрий потрібний світ у Minecraft.
2. Натисни Edit → Open World Folder.
3. Відкрий папку datapacks.
4. Скопіюй цей ZIP-файл у datapacks.
5. Зайди у світ або виконай /reload.

Команди:
/function avaritia_plus:give_infinity_armor — видати Броню нескінченості
/function avaritia_plus:give_reaper_scythe — видати Косу жнеця
/function avaritia_plus:give_all — видати броню і косу

Броня:
- Ефекти працюють тільки коли вдягнуті всі 4 частини броні.
- Невидимість у vanilla Minecraft не ховає саму броню на тілі.

Коса жнеця:
- Базовий предмет: mace.
- При ударі накладає на ціль уповільнення, стан-симуляцію, висушування, отруту і слабкість.
- "Стан" зроблений як blindness + nausea + mining_fatigue, бо у vanilla Minecraft немає окремого stun-ефекту.

Для текстур потрібен окремий Resource Pack.
