Avaritia+ Infinity Armor + Reaper Scythe для Minecraft Java 26.2

Архів містить два ZIP-файли:
1. AvaritiaPlus-Datapack-26.2-v2.zip — покласти у папку datapacks конкретного світу.
2. AvaritiaPlus-ResourcePack-26.2-v2.zip — покласти у папку resourcepacks і активувати в грі.

Команди після встановлення datapack:
/function avaritia_plus:give_infinity_armor
/function avaritia_plus:give_reaper_scythe
/function avaritia_plus:give_all

Якщо світ вже відкритий, після копіювання datapack виконай:
/reload

Коса жнеця:
- Зачарування: Sharpness 50, Wind Burst 10, Density 30, Sweeping Edge 1000.
- При ударі накладає Slowness 3, симуляцію стану, Wither, Poison, Weakness 10.
- Стан у vanilla Minecraft симулюється через Blindness + Nausea + Mining Fatigue.
