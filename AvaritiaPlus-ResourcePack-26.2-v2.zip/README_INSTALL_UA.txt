Avaritia+ Resource Pack для Minecraft Java 26.2

Встановлення:
1. Відкрий Minecraft → Options → Resource Packs → Open Pack Folder.
2. Скопіюй цей ZIP-файл у папку resourcepacks.
3. Активуй ресурс-пак у Minecraft.
4. Для логіки броні і коси також потрібен Datapack.

Що змінює:
- Іконки 4 частин Броні нескінченості в інвентарі.
- Різнокольоровий вигляд броні на персонажі через custom equipment model.
- Іконку Коси жнеця.

Це MVP-текстури. Їх можна замінити на більш красиві PNG без зміни datapack.
